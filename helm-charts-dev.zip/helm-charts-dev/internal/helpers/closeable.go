package helpers

type Closeable func() error
